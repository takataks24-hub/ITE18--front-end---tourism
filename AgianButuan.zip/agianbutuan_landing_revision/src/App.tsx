import { ChangeEvent, FormEvent, ReactNode, useEffect, useMemo, useState } from "react";

type Role = "tourist" | "provider" | "admin";
type ReportStatus = "Pending Verification" | "Verified" | "Rejected" | "More Information Needed";
type Report = {
  id: string;
  title: string;
  type: string;
  route: string;
  date: string;
  reporter: string;
  reporterRole: "Tourist" | "Provider";
  description: string;
  evidence: string;
  status: ReportStatus;
  decision?: string;
};
type Booking = {
  id: string;
  service: string;
  provider: string;
  date: string;
  time: string;
  guests: number;
  status: string;
  affected: boolean;
};
type LinkRequest = {
  id: string;
  reference: string;
  provider: string;
  service: string;
  submitted: string;
  status: "Pending Provider Review" | "Approved" | "Rejected";
};
type Offer = {
  id: string;
  bookingId: string;
  service: string;
  proposedDate: string;
  proposedTime: string;
  note: string;
  status: "Offer Sent" | "Accepted by Tourist" | "Declined" | "Confirmed";
};
type Notice = { id: number; title: string; detail: string; time: string; read: boolean; role: Role | "all" };
type AccountProfile = {
  fullName: string;
  businessName: string;
  businessType: string;
  contactPerson: string;
  email: string;
  mobile: string;
  city: string;
  address: string;
  website: string;
  profilePicture: string;
};

const initialReports: Report[] = [
  {
    id: "DR-2025-041",
    title: "Nasipit ferry cancellation",
    type: "Ferry cancellation",
    route: "Nasipit Port → Jagna",
    date: "2025-04-18",
    reporter: "Mara L. Santos",
    reporterRole: "Tourist",
    description: "The 6:00 AM ferry was cancelled due to rough sea conditions, affecting my scheduled Agusan River tour.",
    evidence: "Carrier cancellation advisory (screenshot)",
    status: "Verified",
    decision: "Verified against the carrier advisory submitted. Bookings on 18 April may be assessed.",
  },
  {
    id: "DR-2025-044",
    title: "Butuan–Cagayan road closure",
    type: "Road closure",
    route: "Butuan–Cagayan de Oro Road, Buenavista",
    date: "2025-04-22",
    reporter: "Mara L. Santos",
    reporterRole: "Tourist",
    description: "A temporary road closure caused a missed hotel arrival window.",
    evidence: "Photo of posted road advisory",
    status: "Pending Verification",
  },
  {
    id: "DR-2025-039",
    title: "River tour suspended",
    type: "Activity cancellation",
    route: "Agusan River, Butuan City",
    date: "2025-04-19",
    reporter: "Balangay River Experiences",
    reporterRole: "Provider",
    description: "All afternoon river departures suspended because of unsafe water levels.",
    evidence: "Operations log and PAGASA bulletin reference",
    status: "Verified",
    decision: "Evidence is sufficient. Afternoon departures are eligible for affected-booking review.",
  },
];

const bookings: Booking[] = [
  { id: "AB-48219", service: "Agusan Heritage River Tour", provider: "Balangay River Experiences", date: "18 Apr 2025", time: "2:30 PM", guests: 2, status: "Affected", affected: true },
  { id: "AB-47503", service: "Two-night Garden Room", provider: "Timber City Inn", date: "22 Apr 2025", time: "3:00 PM", guests: 2, status: "Confirmed", affected: false },
  { id: "AB-46882", service: "Balangay Shrine Guided Visit", provider: "Lakbay Agusan Tours", date: "27 Apr 2025", time: "9:00 AM", guests: 3, status: "Confirmed", affected: false },
  { id: "AB-45571", service: "Airport Transfer", provider: "Caraga Gateway Transport", date: "19 Apr 2025", time: "11:15 AM", guests: 1, status: "Completed", affected: false },
];

const nav: Record<Role, { group: string; items: { id: string; label: string; icon: string }[] }[]> = {
  tourist: [
    { group: "Overview", items: [{ id: "dashboard", label: "Dashboard", icon: "grid" }] },
    { group: "My travel", items: [
      { id: "bookings", label: "My bookings", icon: "calendar" },
      { id: "report", label: "Report a disruption", icon: "alert" },
      { id: "reports", label: "My reports", icon: "file" },
      { id: "links", label: "Booking-link requests", icon: "link" },
      { id: "offers", label: "Rescheduling", icon: "swap" },
    ] },
    { group: "Account", items: [
      { id: "notifications", label: "Notifications", icon: "bell" },
      { id: "profile", label: "Profile & settings", icon: "user" },
    ] },
  ],
  provider: [
    { group: "Overview", items: [{ id: "dashboard", label: "Dashboard", icon: "grid" }] },
    { group: "Operations", items: [
      { id: "bookings", label: "Booking management", icon: "calendar" },
      { id: "links", label: "Link request review", icon: "link" },
      { id: "reports", label: "Disruption reports", icon: "alert" },
      { id: "affected", label: "Affected bookings", icon: "users" },
      { id: "offers", label: "Alternative schedules", icon: "swap" },
      { id: "rescheduling", label: "Rescheduling", icon: "check" },
    ] },
    { group: "Account", items: [
      { id: "notifications", label: "Notifications", icon: "bell" },
      { id: "profile", label: "Provider profile", icon: "building" },
    ] },
  ],
  admin: [
    { group: "Overview", items: [{ id: "dashboard", label: "Dashboard", icon: "grid" }] },
    { group: "System oversight", items: [
      { id: "verification", label: "Verification queue", icon: "check" },
      { id: "users", label: "User management", icon: "users" },
      { id: "providers", label: "Provider management", icon: "building" },
      { id: "rescheduling", label: "Booking overview", icon: "calendar" },
      { id: "history", label: "Update history", icon: "history" },
      { id: "activity", label: "System activity", icon: "pulse" },
    ] },
  ],
};

const labels: Record<Role, { name: string; detail: string; initials: string }> = {
  tourist: { name: "Mara L. Santos", detail: "Tourist account", initials: "MS" },
  provider: { name: "Balangay River Experiences", detail: "Tourism provider", initials: "BR" },
  admin: { name: "Elena D. Reyes", detail: "System administrator", initials: "ER" },
};

const initialProfiles: Record<Role, AccountProfile> = {
  tourist: {
    fullName: "Mara L. Santos",
    businessName: "",
    businessType: "",
    contactPerson: "",
    email: "mara.santos@example.test",
    mobile: "+63 917 555 0134",
    city: "Butuan City",
    address: "",
    website: "",
    profilePicture: "",
  },
  provider: {
    fullName: "",
    businessName: "Balangay River Experiences",
    businessType: "Tour operator",
    contactPerson: "Operations Manager",
    email: "operations@balangayriver.test",
    mobile: "+63 917 555 0134",
    city: "Butuan City",
    address: "Riverside District, Butuan City",
    website: "",
    profilePicture: "",
  },
  admin: {
    fullName: "Elena D. Reyes",
    businessName: "",
    businessType: "",
    contactPerson: "",
    email: "elena.reyes@agianbutuan.test",
    mobile: "+63 917 555 0110",
    city: "Butuan City",
    address: "",
    website: "",
    profilePicture: "",
  },
};

function initialsFromName(name: string) {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (!parts.length) return "AB";
  return `${parts[0][0]}${parts.length > 1 ? parts[parts.length - 1][0] : parts[0][1] || ""}`.toUpperCase();
}

function optimizeProfilePicture(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error("The selected image could not be read."));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error("The selected file is not a supported image."));
      image.onload = () => {
        const maxDimension = 512;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext("2d");
        if (!context) {
          reject(new Error("Image processing is unavailable in this browser."));
          return;
        }
        context.fillStyle = "#ffffff";
        context.fillRect(0, 0, canvas.width, canvas.height);
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.82));
      };
      image.src = String(reader.result || "");
    };
    reader.readAsDataURL(file);
  });
}

function AccountAvatar({ src, initials, className }: { src?: string; initials: string; className: string }) {
  return <span className={className}>{src ? <img src={src} alt="" /> : initials}</span>;
}

function Icon({ name, size = 18 }: { name: string; size?: number }) {
  const paths: Record<string, ReactNode> = {
    grid: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    calendar: <><rect x="3" y="5" width="18" height="16" rx="2"/><path d="M16 3v4M8 3v4M3 10h18"/></>,
    alert: <><path d="M10.3 3.8 2.5 17.2A2 2 0 0 0 4.2 20h15.6a2 2 0 0 0 1.7-2.8L13.7 3.8a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4M12 17h.01"/></>,
    file: <><path d="M6 2h9l5 5v15H6z"/><path d="M14 2v6h6M9 13h6M9 17h6"/></>,
    link: <><path d="M10 13a5 5 0 0 0 7.5.5l2-2a5 5 0 0 0-7-7l-1.1 1.1"/><path d="M14 11a5 5 0 0 0-7.5-.5l-2 2a5 5 0 0 0 7 7l1.1-1.1"/></>,
    swap: <><path d="m17 3 4 4-4 4M3 7h18M7 21l-4-4 4-4M21 17H3"/></>,
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 22a8 8 0 0 1 16 0"/></>,
    building: <><path d="M4 22V3h12v19M16 9h4v13M8 7h4M8 11h4M8 15h4M2 22h20"/></>,
    users: <><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/></>,
    check: <><path d="m20 6-11 11-5-5"/></>,
    history: <><path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5M12 7v5l3 2"/></>,
    pulse: <><path d="M3 12h4l2-7 4 14 2-7h6"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    arrow: <><path d="M5 12h14M13 6l6 6-6 6"/></>,
    search: <><circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/></>,
    menu: <><path d="M4 7h16M4 12h16M4 17h16"/></>,
    close: <><path d="m6 6 12 12M18 6 6 18"/></>,
    plus: <><path d="M12 5v14M5 12h14"/></>,
    logout: <><path d="M10 17l5-5-5-5M15 12H3M21 19V5a2 2 0 0 0-2-2h-6"/></>,
    info: <><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></>,
    image: <><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/></>,
    lock: <><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3M12 14v3"/></>,
    shield: <path d="M12 3 20 6v5c0 5-3.4 8-8 10-4.6-2-8-5-8-10V6z"/>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name]}</svg>;
}

function Logo({ light = false }: { light?: boolean }) {
  return <div className={`logo ${light ? "logo-light" : ""}`}><img className="logo-image" src="/agianbutuan-logo.png" alt="" aria-hidden="true"/><span><b>Agian</b>Butuan<small>Travel coordination</small></span></div>;
}

function Status({ children }: { children: string }) {
  const key = children.toLowerCase().replaceAll(" ", "-");
  return <span className={`status status-${key}`}>{children}</span>;
}

function Button({ children, variant = "primary", onClick, type = "button", disabled = false, icon }: { children: ReactNode; variant?: "primary" | "secondary" | "ghost" | "danger"; onClick?: () => void; type?: "button" | "submit"; disabled?: boolean; icon?: string }) {
  return <button className={`btn btn-${variant}`} onClick={onClick} type={type} disabled={disabled}>{icon && <Icon name={icon} size={16}/>} {children}</button>;
}

function PageHead({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description: string; action?: ReactNode }) {
  return <div className="page-head"><div>{eyebrow && <div className="eyebrow">{eyebrow}</div>}<h1>{title}</h1><p>{description}</p></div>{action}</div>;
}

function Field({ label, required, hint, children }: { label: string; required?: boolean; hint?: string; children: ReactNode }) {
  return <label className="field"><span>{label}{required && <em> *</em>}</span>{children}{hint && <small>{hint}</small>}</label>;
}

function Metric({ label, value, note, icon, tone = "" }: { label: string; value: number | string; note: string; icon: string; tone?: string }) {
  return <div className="metric"><div className={`metric-icon ${tone}`}><Icon name={icon}/></div><div><span>{label}</span><strong>{value}</strong><small>{note}</small></div></div>;
}

function Landing({ onEnter }: { onEnter: (role: Role) => void }) {
  const [showLogin, setShowLogin] = useState(false);
  const [showRegister, setShowRegister] = useState(false);
  const [role, setRole] = useState<Role>("tourist");
  const openLogin = (target: Role) => {
    setRole(target);
    setShowRegister(false);
    setShowLogin(true);
  };
  if (showLogin || showRegister) {
    return <div className="auth-page">
      {!showRegister && <div className="auth-brand">
        <Logo light />
        <div className="auth-message"><span>Coordination, not confusion.</span><h1>Your travel plans changed.<br/>Your next step shouldn’t be unclear.</h1><p>AgianButuan helps tourists and local providers coordinate affected bookings through one clear, verified process.</p></div>
        <p className="photo-credit">AgianButuan · Butuan City, Philippines</p>
      </div>}
      <div className="auth-panel">
        <button className="back-link" onClick={() => { setShowLogin(false); setShowRegister(false); }}>← Back to home</button>
        <div className="auth-form">
          {showRegister ? <>
            <h2>Register</h2>
            <Field label="Account type" required><div className="role-cards register-tabs">
              {(["tourist", "provider"] as Role[]).map(r => <button type="button" key={r} className={role === r ? "role-card selected" : "role-card"} onClick={() => setRole(r)}><span>{r === "tourist" ? "Tourist" : "Tourism service provider"}</span></button>)}
            </div></Field>
            {role === "tourist" ? <>
              <div className="form-grid"><Field label="Full name" required><input name="fullName" placeholder="" required/></Field><Field label="Mobile number"><input name="mobile" type="tel"/></Field></div>
              <Field label="Home city or town" required><input name="homeCity" required/></Field>
            </> : <>
              <Field label="Business name" required><input name="businessName" required/></Field>
              <div className="form-grid"><Field label="Business type" required><select name="businessType" defaultValue="Accommodation" required><option>Accommodation</option><option>Tour operator</option><option>Transport</option><option>Restaurant</option><option>Tourist attraction</option><option>Other</option></select></Field><Field label="Permit reference (sample)" required><input name="permit" placeholder="DEMO-0000" required/></Field></div>
              <Field label="Business address" required><input name="businessAddress" placeholder="Street or district, Butuan City" required/></Field>
              <div className="form-grid"><Field label="Contact person" required><input name="contactPerson" required/></Field><Field label="Mobile number"><input name="mobile" type="tel"/></Field></div>
            </>}
            <Field label="Email" required><input name="email" type="email" required/></Field>
            <div className="form-grid"><Field label="Password" required><input name="password" type="password" required/></Field><Field label="Confirm password" required><input name="confirmPassword" type="password" required/></Field></div>
            <Button onClick={() => onEnter(role)}>Create account</Button>
          </> : <>
            <div className="eyebrow">Welcome back</div><h2>Sign in to your account</h2><p>This is a simulated sign-in for demonstration purposes.</p>
            <Field label="Account type" required><div className="role-cards">{(["tourist", "provider", "admin"] as Role[]).map(r => <button type="button" key={r} className={role === r ? "role-card selected" : "role-card"} onClick={() => setRole(r)}><Icon name={r === "tourist" ? "user" : r === "provider" ? "building" : "check"}/><span>{r === "admin" ? "Administrator" : r[0].toUpperCase() + r.slice(1)}</span></button>)}</div></Field>
            <Field label="Email address" required><input key={role} type="email" defaultValue={role === "tourist" ? "mara.santos@example.test" : role === "provider" ? "operations@balangayriver.test" : "elena.reyes@agianbutuan.test"}/></Field>
            <Field label="Password" required><input type="password" defaultValue="demopassword"/></Field><Button onClick={() => onEnter(role)}>Continue to dashboard <Icon name="arrow" size={16}/></Button>
          </>}
          <div className="auth-switch">{showRegister ? "Already registered?" : "New to AgianButuan?"} <button onClick={() => { if (showRegister) { setShowRegister(false); setShowLogin(true); } else { if (role === "admin") setRole("tourist"); setShowRegister(true); setShowLogin(false); } }}>{showRegister ? "Log in" : "Create account"}</button></div>
        </div>
      </div>
    </div>;
  }
  return <div className="landing">
    <header className="public-nav"><Logo/><nav><a href="#about">About</a><a href="#how">How it works</a><a href="#portals">Portals</a><a href="#scope">System scope</a></nav><div className="nav-actions"><Button variant="ghost" onClick={() => openLogin("tourist")}>Sign in</Button><Button onClick={() => setShowRegister(true)}>Create account</Button></div></header>
    <main>
      <section className="hero">
        <div className="hero-copy">
          <div className="eyebrow">Butuan City travel coordination</div>
          <h1>When travel changes, keep every booking moving forward.</h1>
          <p>Report disruptions, verify affected bookings, and coordinate new schedules with participating tourism providers—all in one clear process.</p>
          <div className="hero-actions"><Button onClick={() => openLogin("tourist")}>Explore the demo <Icon name="arrow" size={16}/></Button><Button variant="secondary" onClick={() => document.querySelector("#how")?.scrollIntoView({ behavior: "smooth" })}>See how it works</Button></div>
          <div className="trust-row"><span><Icon name="check" size={16}/> Administrator-verified reports</span><span><Icon name="check" size={16}/> Private booking records</span><span><Icon name="check" size={16}/> Clear status tracking</span></div>
        </div>
        <div className="hero-visual">
          <img src="/login-background.png" alt="AgianButuan branded riverside landscape with sailboat identity"/>
          <div className="hero-caption"><span>Gateway to Caraga</span><b>Butuan City, Philippines</b></div>
        </div>
      </section>
      <section className="about-strip" id="about"><div><span className="section-number">01</span><h2>Built for the moments between a changed plan and a confirmed solution.</h2></div><p>AgianButuan is not another booking site. It gives tourists, tourism providers, and administrators a shared workflow for documenting disruptions and coordinating registered bookings—without confusing a verified event with a confirmed booking change.</p></section>
      <section className="how" id="how">
        <div className="section-heading"><div className="eyebrow">One coordinated process</div><h2>From disruption to resolution</h2><p>Every action has an owner, a status, and a visible next step.</p></div>
        <div className="steps">
          {[
            ["01", "Report", "A tourist or provider submits the disruption details and available evidence.", "alert"],
            ["02", "Verify", "An administrator reviews the report and records a clear decision.", "check"],
            ["03", "Coordinate", "The provider identifies affected bookings and proposes an alternative.", "swap"],
            ["04", "Confirm", "The tourist decides, then the provider confirms the booking was updated.", "calendar"],
          ].map(([n,t,d,i]) => <div className="step" key={n}><div className="step-top"><span>{n}</span><Icon name={i}/></div><h3>{t}</h3><p>{d}</p></div>)}
        </div>
      </section>
      <section className="portal-access" id="portals">
        <div className="section-heading"><div className="eyebrow">Choose your workspace</div><h2>One platform, three connected portals.</h2><p>Select a role to open the matching demo workspace. Every arrow below is an active shortcut.</p></div>
        <div className="portal-grid">
          <button type="button" className="portal-card" onClick={() => openLogin("tourist")}>
            <span className="portal-icon"><Icon name="user" size={21}/></span><span className="portal-copy"><b>Tourist portal</b><small>Track bookings, report disruptions, and respond to schedule changes.</small></span><span className="portal-arrow"><Icon name="chevron" size={19}/></span>
          </button>
          <button type="button" className="portal-card" onClick={() => openLogin("provider")}>
            <span className="portal-icon"><Icon name="building" size={21}/></span><span className="portal-copy"><b>Provider portal</b><small>Review requests, manage affected bookings, and coordinate alternatives.</small></span><span className="portal-arrow"><Icon name="chevron" size={19}/></span>
          </button>
          <button type="button" className="portal-card" onClick={() => openLogin("admin")}>
            <span className="portal-icon"><Icon name="shield" size={21}/></span><span className="portal-copy"><b>Administrator portal</b><small>Verify reports, oversee accounts, and review system activity.</small></span><span className="portal-arrow"><Icon name="chevron" size={19}/></span>
          </button>
        </div>
      </section>
      <section className="scope" id="scope"><div><div className="eyebrow">Purposefully focused</div><h2>A credible coordination layer for participating businesses.</h2></div><div className="scope-list"><p><Icon name="check"/> User-submitted reports, reviewed by an administrator</p><p><Icon name="check"/> Registered bookings with participating Butuan providers</p><p><Icon name="check"/> In-system offers, decisions, and status updates</p><p><Icon name="info"/> No live schedules, payments, refunds, or automatic external booking changes</p></div></section>
    </main>
    <footer><Logo light/><p>Academic system prototype · Fictional records only</p><button onClick={() => openLogin("tourist")}>Open demo <Icon name="arrow" size={15}/></button></footer>
  </div>;
}

function AppShell({ role, setRole, exit, children, page, setPage, unread, account }: { role: Role; setRole: (r: Role) => void; exit: () => void; children: ReactNode; page: string; setPage: (p: string) => void; unread: number; account: { name: string; detail: string; initials: string; avatar?: string } }) {
  const [mobile, setMobile] = useState(false);
  return <div className="app-shell">
    <aside className={mobile ? "sidebar open" : "sidebar"}>
      <div className="sidebar-top"><Logo light/><button className="mobile-close" onClick={() => setMobile(false)}><Icon name="close"/></button></div>
      <div className="role-switch"><span>Demo view</span><select value={role} onChange={e => { setRole(e.target.value as Role); setPage("dashboard"); }}><option value="tourist">Tourist</option><option value="provider">Provider</option><option value="admin">Administrator</option></select></div>
      <nav className="side-nav">{nav[role].map(section => <div key={section.group}><small>{section.group}</small>{section.items.map(item => <button key={item.id} className={page === item.id ? "active" : ""} onClick={() => { setPage(item.id); setMobile(false); }}><Icon name={item.icon}/><span>{item.label}</span>{item.id === "notifications" && unread > 0 && <b>{unread}</b>}</button>)}</div>)}</nav>
      <div className="user-panel"><AccountAvatar src={account.avatar} initials={account.initials} className="avatar" /><div><strong>{account.name}</strong><small>{account.detail}</small></div><button onClick={exit} title="Exit demo"><Icon name="logout"/></button></div>
    </aside>
    {mobile && <div className="scrim" onClick={() => setMobile(false)}/>}
    <div className="app-main">
      <header className="topbar"><button className="menu-btn" onClick={() => setMobile(true)}><Icon name="menu"/></button><div className="breadcrumb"><span>AgianButuan</span><Icon name="chevron" size={14}/><b>{nav[role].flatMap(s => s.items).find(i => i.id === page)?.label || "Dashboard"}</b></div><div className="top-actions"><button className="icon-btn" onClick={() => setPage("notifications")}><Icon name="bell"/>{unread > 0 && <span/>}</button><AccountAvatar src={account.avatar} initials={account.initials} className="top-avatar" /></div></header>
      <main className="workspace">{children}</main>
    </div>
  </div>;
}

function TouristDashboard({ setPage, reports, offers, links, name }: { setPage: (p: string) => void; reports: Report[]; offers: Offer[]; links: LinkRequest[]; name: string }) {
  const activeOffer = offers.find(o => o.status === "Offer Sent");
  return <>
    <PageHead eyebrow="Tuesday, 22 April 2025" title={`Good morning, ${name.trim().split(/\s+/)[0] || "traveller"}`} description="Here’s what needs your attention across your registered travel plans." action={<Button onClick={() => setPage("report")} icon="plus">Report disruption</Button>}/>
    <div className="metrics"><Metric label="Registered bookings" value={bookings.length} note="1 currently affected" icon="calendar"/><Metric label="Open reports" value={reports.filter(r => r.reporterRole === "Tourist" && r.status === "Pending Verification").length} note="Awaiting verification" icon="alert" tone="amber"/><Metric label="Schedule offers" value={offers.filter(o => o.status === "Offer Sent").length} note="Your response needed" icon="swap" tone="blue"/><Metric label="Link requests" value={links.filter(l => l.status === "Pending Provider Review").length} note="Pending provider review" icon="link" tone="gray"/></div>
    <div className="dashboard-grid">
      <section className="panel attention-panel"><div className="panel-head"><div><span className="kicker">Action required</span><h2>One booking needs your response</h2></div><Icon name="alert"/></div>
        {activeOffer ? <div className="attention-body"><div className="booking-mark"><span>APR</span><b>24</b></div><div className="attention-info"><Status>{activeOffer.status}</Status><h3>{activeOffer.service}</h3><p>New proposed schedule: <b>{activeOffer.proposedDate} at {activeOffer.proposedTime}</b></p><small>Booking {activeOffer.bookingId} · Balangay River Experiences</small></div><Button onClick={() => setPage("offers")} variant="secondary">Review offer <Icon name="arrow" size={15}/></Button></div> : <div className="empty-compact"><Icon name="check"/><div><b>You’re all caught up</b><span>No schedule offers need your response.</span></div></div>}
      </section>
      <section className="panel"><div className="panel-title"><div><h2>Recent updates</h2><p>Status changes on your records</p></div><button onClick={() => setPage("notifications")}>View all</button></div>
        <div className="timeline">
          <div><span className="timeline-dot green"><Icon name="check" size={14}/></span><p><b>Disruption report verified</b><small>Nasipit ferry cancellation · 2 hours ago</small></p></div>
          <div><span className="timeline-dot gold"><Icon name="swap" size={14}/></span><p><b>Alternative schedule received</b><small>Agusan Heritage River Tour · Yesterday</small></p></div>
          <div><span className="timeline-dot gray"><Icon name="link" size={14}/></span><p><b>Booking link under review</b><small>Timber City Inn · 2 days ago</small></p></div>
        </div>
      </section>
      <section className="panel full"><div className="panel-title"><div><h2>Upcoming bookings</h2><p>Your registered plans with participating providers</p></div><button onClick={() => setPage("bookings")}>View all bookings</button></div><BookingTable rows={bookings.slice(0, 3)}/></section>
    </div>
  </>;
}

function ProviderDashboard({ setPage, links, offers, businessName }: { setPage: (p: string) => void; links: LinkRequest[]; offers: Offer[]; businessName: string }) {
  return <>
    <PageHead eyebrow="Operations overview" title={businessName || "Tourism provider"} description="Monitor affected bookings and keep every rescheduling decision moving." action={<Button onClick={() => setPage("reports")} icon="plus">Report disruption</Button>}/>
    <div className="metrics"><Metric label="Active bookings" value="18" note="Next 30 days" icon="calendar"/><Metric label="Affected bookings" value={bookings.filter(b => b.affected).length} note="Review required" icon="alert" tone="amber"/><Metric label="Link requests" value={links.filter(l => l.status === "Pending Provider Review").length} note="Awaiting review" icon="link" tone="blue"/><Metric label="Pending confirmations" value={offers.filter(o => o.status === "Accepted by Tourist").length} note="Update booking record" icon="check" tone="gray"/></div>
    <div className="dashboard-grid">
      <section className="panel attention-panel"><div className="panel-head"><div><span className="kicker">Operational notice</span><h2>Verified river suspension affects a departure</h2></div><Status>Verified</Status></div><div className="notice-summary"><div><span>Disruption</span><b>DR-2025-039</b></div><div><span>Affected date</span><b>19 Apr 2025</b></div><div><span>Potential matches</span><b>1 booking</b></div><Button variant="secondary" onClick={() => setPage("affected")}>Review booking</Button></div></section>
      <section className="panel"><div className="panel-title"><div><h2>Workflow status</h2><p>Current rescheduling pipeline</p></div></div><div className="progress-list"><div><span>Affected</span><b>2</b></div><div><span>Offer sent</span><b>{offers.filter(o => o.status === "Offer Sent").length}</b></div><div><span>Tourist accepted</span><b>{offers.filter(o => o.status === "Accepted by Tourist").length}</b></div><div><span>Confirmed</span><b>{offers.filter(o => o.status === "Confirmed").length}</b></div></div></section>
      <section className="panel full"><div className="panel-title"><div><h2>Upcoming service bookings</h2><p>Fictional booking records for this provider</p></div><button onClick={() => setPage("bookings")}>Manage records</button></div><BookingTable rows={bookings.filter(b => b.provider === "Balangay River Experiences")}/></section>
    </div>
  </>;
}

function AdminDashboard({ setPage, reports, offers }: { setPage: (p: string) => void; reports: Report[]; offers: Offer[] }) {
  return <>
    <PageHead eyebrow="System oversight" title="Administrator overview" description="Review incoming reports and monitor booking coordination across participating providers." action={<Button onClick={() => setPage("verification")}>Open verification queue <Icon name="arrow" size={16}/></Button>}/>
    <div className="metrics"><Metric label="Pending verification" value={reports.filter(r => r.status === "Pending Verification").length} note="Oldest: 3 hours" icon="file" tone="amber"/><Metric label="Verified disruptions" value={reports.filter(r => r.status === "Verified").length} note="This month" icon="check"/><Metric label="Affected bookings" value="7" note="Across 4 providers" icon="calendar" tone="blue"/><Metric label="Active coordinations" value={offers.filter(o => o.status !== "Confirmed").length} note="1 needs follow-up" icon="swap" tone="gray"/></div>
    <div className="dashboard-grid">
      <section className="panel wide"><div className="panel-title"><div><h2>Verification queue</h2><p>Reports requiring an administrator decision</p></div><button onClick={() => setPage("verification")}>Review all</button></div><ReportTable reports={reports.filter(r => r.status === "Pending Verification").slice(0, 4)} onSelect={() => setPage("verification")}/></section>
      <section className="panel"><div className="panel-title"><div><h2>System pulse</h2><p>Activity in the last 7 days</p></div></div><div className="pulse-total"><strong>32</strong><span>recorded activities</span></div><div className="mini-bars">{[35,62,45,78,55,92,70].map((h,i) => <i key={i} style={{ height: `${h}%` }}/>)}</div><div className="bar-labels"><span>M</span><span>T</span><span>W</span><span>T</span><span>F</span><span>S</span><span>S</span></div></section>
      <section className="panel full"><div className="panel-title"><div><h2>Recent system activity</h2><p>Important decisions and workflow updates</p></div><button onClick={() => setPage("activity")}>Full activity log</button></div><ActivityList/></section>
    </div>
  </>;
}

function BookingTable({ rows }: { rows: Booking[] }) {
  const [selected, setSelected] = useState<Booking | null>(null);
  return <>
    <div className="table-wrap"><table><thead><tr><th>Booking</th><th>Service</th><th>Schedule</th><th>Guests</th><th>Status</th><th></th></tr></thead><tbody>{rows.map(b => <tr key={b.id}><td><b>{b.id}</b></td><td><b>{b.service}</b><small>{b.provider}</small></td><td>{b.date}<small>{b.time}</small></td><td>{b.guests}</td><td><Status>{b.status}</Status></td><td><button type="button" className="table-action" aria-label={`View booking ${b.id}`} onClick={() => setSelected(b)}><Icon name="chevron" size={16}/></button></td></tr>)}</tbody></table></div>
    {selected && <div className="modal-backdrop" role="presentation" onClick={() => setSelected(null)}><section className="modal detail-modal" role="dialog" aria-modal="true" aria-labelledby="booking-detail-title" onClick={event => event.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">Booking details</div><h2 id="booking-detail-title">{selected.id}</h2></div><button type="button" aria-label="Close booking details" onClick={() => setSelected(null)}><Icon name="close"/></button></div><div className="modal-detail-grid"><div><span>Service</span><b>{selected.service}</b></div><div><span>Provider</span><b>{selected.provider}</b></div><div><span>Schedule</span><b>{selected.date} · {selected.time}</b></div><div><span>Guests</span><b>{selected.guests}</b></div><div><span>Status</span><b><Status>{selected.status}</Status></b></div><div><span>Disruption review</span><b>{selected.affected ? "Flagged as affected" : "No disruption flagged"}</b></div></div><div className="form-actions"><Button onClick={() => setSelected(null)}>Close details</Button></div></section></div>}
  </>;
}

function ReportTable({ reports, onSelect }: { reports: Report[]; onSelect: (r: Report) => void }) {
  return <div className="table-wrap"><table><thead><tr><th>Report</th><th>Disruption</th><th>Submitted by</th><th>Event date</th><th>Status</th><th></th></tr></thead><tbody>{reports.map(r => <tr key={r.id} onClick={() => onSelect(r)} className="click-row"><td><b>{r.id}</b></td><td><b>{r.title}</b><small>{r.route}</small></td><td>{r.reporter}<small>{r.reporterRole}</small></td><td>{formatDate(r.date)}</td><td><Status>{r.status}</Status></td><td><button type="button" className="table-action" aria-label={`View report ${r.id}`} onClick={event => { event.stopPropagation(); onSelect(r); }}><Icon name="chevron" size={16}/></button></td></tr>)}</tbody></table></div>;
}

function ReportsPage({ role, reports, setReports, notify, startForm = false }: { role: Role; reports: Report[]; setReports: (r: Report[]) => void; notify: (title: string, detail: string, role: Role) => void; startForm?: boolean }) {
  const [form, setForm] = useState(startForm);
  const [selected, setSelected] = useState<Report | null>(null);
  const [error, setError] = useState("");
  const mine = reports.filter(r => role === "admin" || (role === "tourist" ? r.reporterRole === "Tourist" : r.reporterRole === "Provider"));
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    if (!data.get("type") || !data.get("route") || !data.get("date") || !data.get("description")) { setError("Complete all required fields before submitting."); return; }
    const type = String(data.get("type"));
    const report: Report = { id: `DR-2025-${String(45 + reports.length).padStart(3,"0")}`, title: `${type} report`, type, route: String(data.get("route")), date: String(data.get("date")), reporter: labels[role].name, reporterRole: role === "tourist" ? "Tourist" : "Provider", description: String(data.get("description")), evidence: String(data.get("evidence") || "No supporting file attached"), status: "Pending Verification" };
    setReports([report, ...reports]); notify("Disruption report submitted", `${report.id} is awaiting administrator verification.`, role); setSelected(report); setForm(false); setError("");
  };
  if (form) return <><PageHead eyebrow="New report" title="Report a travel disruption" description="Provide clear, factual details. An administrator will review this report before it can affect bookings."/><div className="form-layout"><form className="panel form-panel" onSubmit={submit}><div className="form-section"><h2>Disruption details</h2><p>Fields marked with an asterisk are required.</p><div className="form-grid"><Field label="Disruption type" required><select name="type" defaultValue=""><option value="" disabled>Select a type</option><option>Ferry cancellation</option><option>Flight delay</option><option>Road closure</option><option>Weather interruption</option><option>Activity cancellation</option></select></Field><Field label="Date affected" required><input name="date" type="date"/></Field><Field label="Affected location or route" required><input name="route" placeholder="e.g. Bancasi Airport → Butuan City"/></Field><Field label="Time (if known)"><input name="time" type="time"/></Field></div><Field label="What happened?" required hint="Do not include sensitive personal or payment information."><textarea name="description" rows={5} placeholder="Describe how the event affected or may affect your registered booking."/></Field></div><div className="form-section"><h2>Supporting evidence</h2><Field label="Supporting evidence" hint="Describe the advisory, notice, message or photo you have."><input name="evidence" placeholder=""/></Field><Field label="Attach a file (optional)" hint="Simulation: the file is not uploaded. Only its name is recorded with the report."><input name="evidenceFile" type="file" accept="image/*,.pdf,.doc,.docx"/></Field><Field label="Related booking (optional)" hint="Only your own linked bookings are listed. If your booking is not listed, request a link first."><select name="booking" defaultValue=""><option value="">No specific booking</option>{bookings.map(b => <option key={b.id} value={b.id}>{b.id} — {b.provider}</option>)}</select></Field><p className="field-note">Booking not listed? <button type="button" className="text-link" onClick={() => notify("Booking link request", "Request a booking link from your provider.", role)}>Request a booking link</button>.</p></div>{error && <div className="form-error"><Icon name="alert" size={16}/>{error}</div>}<div className="form-actions"><Button variant="ghost" onClick={() => setForm(false)}>Cancel</Button><Button type="submit">Submit for verification</Button></div></form><aside className="form-aside"><div className="info-box"><Icon name="info"/><h3>Before you submit</h3><p>This system does not automatically verify real-world events. An administrator will review the details and evidence information you provide.</p></div><div className="process-box"><span>1</span><p><b>Submit report</b><small>Status: Pending Verification</small></p><span>2</span><p><b>Administrator review</b><small>Evidence and details assessed</small></p><span>3</span><p><b>Decision recorded</b><small>Verified, rejected, or more info needed</small></p></div></aside></div></>;
  if (selected) return <ReportDetail report={selected} onBack={() => setSelected(null)}/>;
  return <><PageHead eyebrow={role === "tourist" ? "My travel records" : "Operational records"} title="Disruption reports" description={role === "tourist" ? "Track the review status and decisions for reports you have submitted." : "View relevant reports or submit an operational disruption for review."} action={<Button onClick={() => setForm(true)} icon="plus">New disruption report</Button>}/><div className="panel list-panel"><div className="filterbar"><div className="search"><Icon name="search"/><input placeholder="Search reports"/></div><select><option>All statuses</option><option>Pending Verification</option><option>Verified</option><option>Rejected</option></select></div><ReportTable reports={mine} onSelect={setSelected}/></div></>;
}

function ReportDetail({ report, onBack, adminActions }: { report: Report; onBack: () => void; adminActions?: ReactNode }) {
  return <><button className="back-link inner" onClick={onBack}>← Back to reports</button><PageHead eyebrow={report.id} title={report.title} description={`Submitted by ${report.reporter} · ${report.reporterRole}`}/><div className="detail-layout"><section className="panel detail-card"><div className="detail-status"><Status>{report.status}</Status><span>Event date: {formatDate(report.date)}</span></div><h2>Report details</h2><dl><div><dt>Disruption type</dt><dd>{report.type}</dd></div><div><dt>Affected location or route</dt><dd>{report.route}</dd></div><div><dt>Date of disruption</dt><dd>{formatDate(report.date)}</dd></div><div><dt>Reporter</dt><dd>{report.reporter}</dd></div></dl><h3>Description</h3><p>{report.description}</p><h3>Supporting evidence information</h3><div className="evidence"><Icon name="file"/><div><b>{report.evidence}</b><span>Evidence description submitted with report</span></div></div>{report.decision && <div className="decision-note"><b>Administrator decision</b><p>{report.decision}</p></div>}</section><aside>{adminActions || <div className="info-box sticky"><Icon name="info"/><h3>What this status means</h3><p>{report.status === "Verified" ? "The disruption event has been verified. This does not by itself confirm a change to an individual booking." : "This report has not yet been verified and cannot be used to confirm booking changes."}</p></div>}</aside></div></>;
}

function VerificationPage({ reports, setReports, notify }: { reports: Report[]; setReports: (r: Report[]) => void; notify: (t: string, d: string, r: Role) => void }) {
  const [selected, setSelected] = useState<Report | null>(null);
  const [decision, setDecision] = useState("");
  const update = (status: ReportStatus) => {
    if (!selected) return;
    const explanation = decision.trim() || (status === "Verified" ? "The submitted details and supporting evidence information are sufficient for verification." : status === "Rejected" ? "The available details do not sufficiently establish the reported disruption." : "Please provide additional supporting details or evidence information.");
    setReports(reports.map(r => r.id === selected.id ? { ...r, status, decision: explanation } : r));
    notify(`Report ${status.toLowerCase()}`, `${selected.id}: ${explanation}`, selected.reporterRole === "Tourist" ? "tourist" : "provider");
    setSelected(null); setDecision("");
  };
  if (selected) return <ReportDetail report={selected} onBack={() => setSelected(null)} adminActions={<div className="panel decision-panel"><div className="eyebrow">Administrator review</div><h2>Record a decision</h2><p>Your explanation will be visible to the submitting user.</p><Field label="Decision explanation"><textarea rows={5} value={decision} onChange={e => setDecision(e.target.value)} placeholder="Summarize your verification decision..."/></Field><div className="decision-actions"><Button onClick={() => update("Verified")}><Icon name="check" size={16}/> Verify report</Button><Button variant="secondary" onClick={() => update("More Information Needed")}>Request information</Button><Button variant="danger" onClick={() => update("Rejected")}>Reject report</Button></div><small className="scope-note">This decision verifies the disruption report only. It does not modify any booking.</small></div>}/>;
  return <><PageHead eyebrow="Administrator review" title="Disruption verification queue" description="Examine submitted details and record an evidence-based decision."/><div className="metrics compact"><Metric label="Awaiting review" value={reports.filter(r => r.status === "Pending Verification").length} note="Requires a decision" icon="file" tone="amber"/><Metric label="More info requested" value={reports.filter(r => r.status === "More Information Needed").length} note="Waiting on reporter" icon="info" tone="blue"/><Metric label="Decided this month" value={reports.filter(r => ["Verified","Rejected"].includes(r.status)).length} note="Verified or rejected" icon="check"/></div><div className="panel list-panel"><div className="filterbar"><div className="search"><Icon name="search"/><input placeholder="Search by report ID, route, or reporter"/></div><select><option>Pending Verification</option><option>All reports</option></select></div><ReportTable reports={reports.filter(r => r.status === "Pending Verification")} onSelect={setSelected}/></div></>;
}

function LinksPage({ role, links, setLinks, notify }: { role: Role; links: LinkRequest[]; setLinks: (l: LinkRequest[]) => void; notify: (t:string,d:string,r:Role)=>void }) {
  const [modal, setModal] = useState(false);
  const [selectedLink, setSelectedLink] = useState<LinkRequest | null>(null);
  const [error, setError] = useState("");
  const submit = (e: FormEvent<HTMLFormElement>) => { e.preventDefault(); const d = new FormData(e.currentTarget); if (!d.get("reference") || !d.get("provider") || !d.get("service")) { setError("Complete all required booking details."); return; } const item: LinkRequest = { id:`BL-${106 + links.length}`, reference:String(d.get("reference")), provider:String(d.get("provider")), service:String(d.get("service")), submitted:"Today", status:"Pending Provider Review" }; setLinks([item,...links]); notify("Booking-link request submitted", `${item.reference} was sent to ${item.provider} for review.`,"tourist"); setModal(false); };
  const decide = (id:string,status:"Approved"|"Rejected") => { const item=links.find(l=>l.id===id); setLinks(links.map(l=>l.id===id?{...l,status}:l)); notify(`Booking-link request ${status.toLowerCase()}`, `${item?.reference} was ${status.toLowerCase()} by the provider.`,"tourist"); };
  return <><PageHead eyebrow={role === "provider" ? "Record matching" : "My booking records"} title={role === "provider" ? "Booking-link request review" : "Booking-link requests"} description={role === "provider" ? "Verify supplied references against your own records before approving account access." : "Request access to an existing booking made with a participating provider."} action={role === "tourist" ? <Button onClick={()=>setModal(true)} icon="plus">Request booking link</Button> : undefined}/><div className="panel list-panel"><div className="filterbar"><div className="search"><Icon name="search"/><input placeholder="Search booking reference or provider"/></div><select><option>All statuses</option><option>Pending Provider Review</option><option>Approved</option></select></div><div className="request-list">{links.map(l=><div className="request-row" key={l.id}><div className="request-icon"><Icon name="link"/></div><div><small>{l.id}</small><h3>{l.service}</h3><p>{l.provider} · Booking reference <b>{l.reference}</b></p></div><div className="request-date"><span>Submitted</span><b>{l.submitted}</b></div><Status>{l.status}</Status><div className="request-row-actions">{role==="provider"&&l.status==="Pending Provider Review"&&<div className="row-actions"><Button variant="secondary" onClick={()=>decide(l.id,"Rejected")}>Reject</Button><Button onClick={()=>decide(l.id,"Approved")}>Approve</Button></div>}<button type="button" className="table-action" aria-label={`View request ${l.id}`} onClick={()=>setSelectedLink(l)}><Icon name="chevron" size={16}/></button></div></div>)}</div></div>{modal&&<div className="modal-backdrop"><form className="modal" onSubmit={submit}><div className="modal-head"><div><div className="eyebrow">New request</div><h2>Link an existing booking</h2></div><button onClick={()=>setModal(false)} type="button"><Icon name="close"/></button></div><p>Enter the details exactly as they appear on your booking confirmation. The provider will review this request.</p><Field label="Booking reference" required><input name="reference" placeholder="e.g. AB-49021"/></Field><Field label="Participating provider" required><select name="provider" defaultValue=""><option value="" disabled>Select provider</option><option>Balangay River Experiences</option><option>Timber City Inn</option><option>Lakbay Agusan Tours</option></select></Field><Field label="Booked service" required><input name="service" placeholder="e.g. Garden Room, 2 nights"/></Field>{error&&<div className="form-error">{error}</div>}<div className="form-actions"><Button variant="ghost" onClick={()=>setModal(false)}>Cancel</Button><Button type="submit">Submit request</Button></div></form></div>}{selectedLink&&<div className="modal-backdrop" role="presentation" onClick={()=>setSelectedLink(null)}><section className="modal detail-modal" role="dialog" aria-modal="true" aria-labelledby="link-detail-title" onClick={event=>event.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">Booking-link request</div><h2 id="link-detail-title">{selectedLink.id}</h2></div><button type="button" aria-label="Close request details" onClick={()=>setSelectedLink(null)}><Icon name="close"/></button></div><div className="modal-detail-grid"><div><span>Service</span><b>{selectedLink.service}</b></div><div><span>Provider</span><b>{selectedLink.provider}</b></div><div><span>Booking reference</span><b>{selectedLink.reference}</b></div><div><span>Date submitted</span><b>{selectedLink.submitted}</b></div><div><span>Status</span><b><Status>{selectedLink.status}</Status></b></div></div>{role==="provider"&&selectedLink.status==="Pending Provider Review"&&<div className="form-actions"><Button variant="secondary" onClick={()=>{decide(selectedLink.id,"Rejected");setSelectedLink(null);}}>Reject request</Button><Button onClick={()=>{decide(selectedLink.id,"Approved");setSelectedLink(null);}}>Approve request</Button></div>}{!(role==="provider"&&selectedLink.status==="Pending Provider Review")&&<div className="form-actions"><Button onClick={()=>setSelectedLink(null)}>Close details</Button></div>}</section></div>}</>;
}

function OffersPage({ role, offers, setOffers, notify }: { role: Role; offers: Offer[]; setOffers: (o: Offer[])=>void; notify:(t:string,d:string,r:Role)=>void }) {
  const [create,setCreate]=useState(false);
  const decide=(id:string,status:"Accepted by Tourist"|"Declined")=>{setOffers(offers.map(o=>o.id===id?{...o,status}:o));notify(`Schedule offer ${status==="Declined"?"declined":"accepted"}`,`${id} was ${status.toLowerCase()}.`,"provider");};
  const confirm=(id:string)=>{setOffers(offers.map(o=>o.id===id?{...o,status:"Confirmed"}:o));notify("Rescheduling confirmed",`${id}: The provider confirmed that the booking record was updated.`,"tourist");};
  const submit=(e:FormEvent<HTMLFormElement>)=>{e.preventDefault();const d=new FormData(e.currentTarget);const offer:Offer={id:`OF-${224+offers.length}`,bookingId:"AB-48219",service:"Agusan Heritage River Tour",proposedDate:String(d.get("date")),proposedTime:String(d.get("time")),note:String(d.get("note")),status:"Offer Sent"};setOffers([offer,...offers]);notify("New alternative schedule",`${offer.service}: ${offer.proposedDate} at ${offer.proposedTime}.`,"tourist");setCreate(false);};
  return <><PageHead eyebrow="Booking coordination" title={role==="tourist"?"Rescheduling requests & offers":role==="provider"?"Alternative schedule management":"Booking & rescheduling overview"} description={role==="tourist"?"Review provider proposals and communicate your decision.":"Track each offer from proposal through confirmed booking update."} action={role==="provider"?<Button icon="plus" onClick={()=>setCreate(true)}>Create schedule offer</Button>:undefined}/><div className="workflow-banner"><Icon name="info"/><p><b>A tourist’s acceptance is not final confirmation.</b> The provider must update its own booking record and confirm that action before the arrangement is complete.</p></div><div className="offer-list">{offers.map(o=><section className="panel offer-card" key={o.id}><div className="offer-top"><div><small>{o.id} · Booking {o.bookingId}</small><h2>{o.service}</h2><p>Balangay River Experiences</p></div><Status>{o.status}</Status></div><div className="schedule-change"><div><span>Original schedule</span><b>18 Apr 2025</b><small>2:30 PM</small></div><Icon name="arrow"/><div className="new-schedule"><span>Proposed alternative</span><b>{o.proposedDate}</b><small>{o.proposedTime}</small></div></div><div className="provider-note"><span>Provider note</span><p>{o.note}</p></div>{role==="tourist"&&o.status==="Offer Sent"&&<div className="offer-actions"><Button variant="secondary" onClick={()=>decide(o.id,"Declined")}>Decline</Button><Button onClick={()=>decide(o.id,"Accepted by Tourist")}>Accept alternative</Button></div>}{role==="provider"&&o.status==="Accepted by Tourist"&&<div className="confirm-box"><div><Icon name="alert"/><p><b>Tourist accepted this offer</b><span>Confirm only after your operational booking record has been updated.</span></p></div><Button onClick={()=>confirm(o.id)}>Confirm booking update</Button></div>}{o.status==="Confirmed"&&<div className="resolved-box"><Icon name="check"/><p><b>Rescheduling confirmed</b><span>The provider recorded that the booking was updated.</span></p></div>}</section>)}</div>{create&&<div className="modal-backdrop"><form className="modal" onSubmit={submit}><div className="modal-head"><div><div className="eyebrow">Affected booking AB-48219</div><h2>Propose an alternative</h2></div><button type="button" onClick={()=>setCreate(false)}><Icon name="close"/></button></div><p>The tourist will be notified and asked to accept or decline this proposed schedule.</p><div className="form-grid"><Field label="Proposed date" required><input name="date" type="date" required/></Field><Field label="Proposed time" required><input name="time" type="time" required/></Field></div><Field label="Explanation" required><textarea name="note" rows={4} required placeholder="Explain the alternative and any relevant arrival instructions."/></Field><div className="form-actions"><Button variant="ghost" onClick={()=>setCreate(false)}>Cancel</Button><Button type="submit">Send offer</Button></div></form></div>}</>;
}

function NotificationsPage({ notices, role, setNotices }: { notices: Notice[]; role: Role; setNotices: (n:Notice[])=>void }) {
  const mine=notices.filter(n=>n.role===role||n.role==="all");
  return <><PageHead eyebrow="In-system updates" title="Notifications" description="Important changes to reports, requests, and booking coordination." action={<Button variant="secondary" onClick={()=>setNotices(notices.map(n=>(n.role===role||n.role==="all")?{...n,read:true}:n))}>Mark all as read</Button>}/><div className="panel notification-list">{mine.map(n=><div className={`notification ${n.read?"":"unread"}`} key={n.id}><span className="notice-icon"><Icon name={n.title.toLowerCase().includes("report")?"file":n.title.toLowerCase().includes("booking")?"calendar":"bell"}/></span><div><h3>{n.title}</h3><p>{n.detail}</p><small>{n.time}</small></div>{!n.read&&<i/>}</div>)}</div></>;
}

function ProfilePage({ role, profile, onSave, currentPassword, onPasswordChange }: {
  role: Role;
  profile: AccountProfile;
  onSave: (profile: AccountProfile) => void;
  currentPassword: string;
  onPasswordChange: (password: string) => void;
}) {
  const [tab, setTab] = useState<"personal" | "security">("personal");
  const [draft, setDraft] = useState<AccountProfile>(profile);
  const [saved, setSaved] = useState(false);
  const [pictureError, setPictureError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordMessage, setPasswordMessage] = useState("");
  useEffect(() => setDraft(profile), [profile]);
  const displayName = role === "provider" ? (profile.businessName || labels.provider.name) : role === "admin" ? (profile.fullName || labels.admin.name) : (profile.fullName || labels.tourist.name);
  const accountType = role === "provider" ? "Tourism provider" : role === "admin" ? "System administrator" : "Tourist account";
  const updateDraft = (field: keyof AccountProfile, value: string) => {
    setDraft(current => ({ ...current, [field]: value }));
    setSaved(false);
  };
  const savePersonalInfo = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    onSave(draft);
    setSaved(true);
  };
  const handleProfilePictureChange = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.currentTarget.files?.[0];
    event.currentTarget.value = "";
    if (!file) return;
    setPictureError("");
    if (!file.type.startsWith("image/")) {
      setPictureError("Choose an image file in JPG, PNG, or WebP format.");
      return;
    }
    if (file.size > 8 * 1024 * 1024) {
      setPictureError("Choose an image smaller than 8 MB.");
      return;
    }
    try {
      const profilePicture = await optimizeProfilePicture(file);
      const nextProfile = { ...draft, profilePicture };
      setDraft(current => ({ ...current, profilePicture }));
      onSave(nextProfile);
      setSaved(true);
    } catch (error) {
      setPictureError(error instanceof Error ? error.message : "The profile picture could not be uploaded.");
    }
  };
  const removeProfilePicture = () => {
    const nextProfile = { ...draft, profilePicture: "" };
    setDraft(current => ({ ...current, profilePicture: "" }));
    onSave(nextProfile);
    setPictureError("");
    setSaved(true);
  };
  const changePassword = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const current = String(data.get("currentPassword") || "");
    const next = String(data.get("newPassword") || "");
    const confirmation = String(data.get("confirmPassword") || "");
    setPasswordMessage("");
    if (current !== currentPassword) {
      setPasswordError("Your current password does not match the demo account password.");
      return;
    }
    if (next.length < 8 || !/[A-Za-z]/.test(next) || !/\d/.test(next)) {
      setPasswordError("Use at least 8 characters, including at least one letter and one number.");
      return;
    }
    if (next !== confirmation) {
      setPasswordError("The new password and confirmation do not match.");
      return;
    }
    if (next === current) {
      setPasswordError("Choose a new password that is different from your current password.");
      return;
    }
    onPasswordChange(next);
    setPasswordError("");
    setPasswordMessage("Password updated for this demo session.");
    event.currentTarget.reset();
  };

  return <>
    <PageHead eyebrow="Account management" title={role === "provider" ? "Provider profile & security" : "Profile & security"} description="Keep your account information current and manage access to your account."/>
    <div className="profile-grid profile-layout">
      <section className="panel profile-card">
        <AccountAvatar src={profile.profilePicture} initials={initialsFromName(displayName)} className="large-avatar" />
        <div className="profile-picture-tools">
          <label className="profile-photo-upload">
            <Icon name="image" size={14}/>
            <span>{profile.profilePicture ? "Change photo" : "Upload profile picture"}</span>
            <input type="file" accept="image/png,image/jpeg,image/webp" onChange={handleProfilePictureChange} aria-label="Upload profile picture" />
          </label>
          {profile.profilePicture && <button type="button" className="profile-photo-remove" onClick={removeProfilePicture}>Remove</button>}
        </div>
        <p className="profile-picture-hint">JPG, PNG or WebP · Max 8 MB</p>
        {pictureError && <div className="form-error profile-picture-error"><Icon name="alert" size={14}/>{pictureError}</div>}
        <h2>{displayName}</h2>
        <p>{accountType}</p>
        <Status>Active</Status>
        <div className="profile-meta">
          <div><span>Account type</span><b>{accountType}</b></div>
          <div><span>Email address</span><b className="profile-email">{profile.email || "Not added"}</b></div>
          <div><span>Location</span><b>{role === "provider" ? (profile.address || profile.city || "Not added") : (profile.city || "Not added")}</b></div>
        </div>
      </section>
      <section className="panel form-panel profile-settings">
        <div className="profile-tabs" role="tablist" aria-label="Profile settings">
          <button type="button" role="tab" aria-selected={tab === "personal"} className={tab === "personal" ? "profile-tab active" : "profile-tab"} onClick={() => setTab("personal")}><Icon name={role === "provider" ? "building" : "user"} size={16}/>{role === "provider" ? "Business information" : "Personal information"}</button>
          <button type="button" role="tab" aria-selected={tab === "security"} className={tab === "security" ? "profile-tab active" : "profile-tab"} onClick={() => setTab("security")}><Icon name="lock" size={16}/>Security settings</button>
        </div>
        {tab === "personal" ? <form onSubmit={savePersonalInfo}>
          <div className="form-section profile-section-head"><h2>{role === "provider" ? "Business information" : "Personal information"}</h2><p>{role === "provider" ? "Update the business details and contact information associated with your provider account." : "Update the contact details associated with your tourist account."}</p></div>
          {role === "provider" ? <div className="form-grid">
            <Field label="Business name" required><input name="businessName" value={draft.businessName} onChange={event => updateDraft("businessName", event.target.value)} required/></Field>
            <Field label="Business type" required><select name="businessType" value={draft.businessType} onChange={event => updateDraft("businessType", event.target.value)} required><option value="">Select business type</option><option>Accommodation</option><option>Tour operator</option><option>Transport</option><option>Restaurant</option><option>Tourist attraction</option><option>Other</option></select></Field>
            <Field label="Contact person" required><input name="contactPerson" value={draft.contactPerson} onChange={event => updateDraft("contactPerson", event.target.value)} required/></Field>
            <Field label="Email address" required><input name="email" type="email" value={draft.email} onChange={event => updateDraft("email", event.target.value)} required/></Field>
            <Field label="Mobile number" required><input name="mobile" type="tel" value={draft.mobile} onChange={event => updateDraft("mobile", event.target.value)} required/></Field>
            <Field label="City or municipality" required><input name="city" value={draft.city} onChange={event => updateDraft("city", event.target.value)} required/></Field>
            <div className="profile-full-field"><Field label="Business address" required><input name="address" value={draft.address} onChange={event => updateDraft("address", event.target.value)} required/></Field></div>
            <div className="profile-full-field"><Field label="Website or business page (optional)"><input name="website" type="url" value={draft.website} onChange={event => updateDraft("website", event.target.value)} placeholder="https://"/></Field></div>
          </div> : <div className="form-grid">
            <Field label="Full name" required><input name="fullName" value={draft.fullName} onChange={event => updateDraft("fullName", event.target.value)} required autoComplete="name"/></Field>
            <Field label="Email address" required><input name="email" type="email" value={draft.email} onChange={event => updateDraft("email", event.target.value)} required autoComplete="email"/></Field>
            <Field label="Mobile number" required><input name="mobile" type="tel" value={draft.mobile} onChange={event => updateDraft("mobile", event.target.value)} required autoComplete="tel"/></Field>
            <Field label="Home city or municipality" required><input name="city" value={draft.city} onChange={event => updateDraft("city", event.target.value)} required autoComplete="address-level2"/></Field>
          </div>}
          {saved && <div className="saved-message"><Icon name="check" size={16}/> Your {role === "provider" ? "business information" : "personal information"} has been saved in this prototype.</div>}
          <div className="form-actions profile-form-actions"><Button type="submit" icon="check">Save changes</Button></div>
        </form> : <form onSubmit={changePassword}>
          <div className="security-intro"><span className="security-symbol"><Icon name="shield" size={22}/></span><div><h2>Password & sign-in</h2><p>Change the password used for this demo account.</p></div></div>
          <Field label="Current password" required><input name="currentPassword" type="password" autoComplete="current-password" required/></Field>
          <div className="form-grid">
            <Field label="New password" required><input name="newPassword" type="password" autoComplete="new-password" minLength={8} required/></Field>
            <Field label="Confirm new password" required><input name="confirmPassword" type="password" autoComplete="new-password" minLength={8} required/></Field>
          </div>
          <p className="password-guidance">Use at least 8 characters, including at least one letter and one number.</p>
          {passwordError && <div className="form-error"><Icon name="alert" size={16}/>{passwordError}</div>}
          {passwordMessage && <div className="saved-message"><Icon name="check" size={16}/>{passwordMessage}</div>}
          <div className="form-actions profile-form-actions"><Button type="submit" icon="lock">Change password</Button></div>
          <div className="security-note"><Icon name="info" size={18}/><p><b>Prototype limitation</b><span>Password changes are simulated for the current session only. A live deployment must connect this form to a secure authentication service and must never store plain-text passwords in the browser.</span></p></div>
        </form>}
      </section>
    </div>
  </>;
}

function GenericPage({ page, role, profiles, setProfiles, currentPassword, onPasswordChange }: { page:string; role:Role; profiles: Record<Role, AccountProfile>; setProfiles: (profiles: Record<Role, AccountProfile>) => void; currentPassword: string; onPasswordChange: (password: string) => void }) {
  const [selectedEntity, setSelectedEntity] = useState<{name:string; detail:string; id:string; status:string; kind:string} | null>(null);
  const titles:Record<string,[string,string]>={bookings:["Booking management","Search and review registered booking records."],affected:["Affected bookings","Review booking records potentially impacted by verified disruptions."],users:["User management","View fictional tourist account records and current account states."],providers:["Provider management","Monitor participating Butuan tourism service providers."],history:["Disruption update history","A traceable record of verification and disruption status changes."],activity:["System activity overview","Review important actions across the coordination workflow."],profile:[role==="provider"?"Provider profile & security":"Profile & security","Update account information and manage account security."]};
  const [title,desc]=titles[page]||["System records","Review prototype records and workflow activity."];
  if(page==="bookings"||page==="affected")return <><PageHead eyebrow={role==="provider"?"Provider records":"My travel"} title={title} description={desc}/><div className="panel list-panel"><div className="filterbar"><div className="search"><Icon name="search"/><input placeholder="Search by booking reference or service"/></div><select><option>All statuses</option><option>Affected</option><option>Confirmed</option></select></div><BookingTable rows={page==="affected"?bookings.filter(b=>b.affected):bookings}/></div></>;
  if(page==="users"||page==="providers") {
    const entities: [string,string,string,string][] = page==="users"
      ? [["Mara L. Santos","mara.santos@example.test","Tourist","Active"],["Paolo M. Rivera","paolo.rivera@example.test","Tourist","Active"],["Janelle C. Cruz","janelle.cruz@example.test","Tourist","Review"]]
      : [["Balangay River Experiences","River tour operator","TP-001","Active"],["Timber City Inn","Accommodation","TP-004","Active"],["Lakbay Agusan Tours","Tour operator","TP-007","Active"]];
    return <><PageHead eyebrow="Administrator records" title={title} description={desc}/><div className="panel list-panel"><div className="filterbar"><div className="search"><Icon name="search"/><input placeholder={`Search ${page}`}/></div><Button variant="secondary" disabled>Export unavailable in prototype</Button></div><div className="entity-list">{entities.map((x,i)=><div key={i}><span className="avatar">{x[0].split(" ").map(y=>y[0]).slice(0,2).join("")}</span><div><b>{x[0]}</b><small>{x[1]}</small></div><span>{x[2]}</span><Status>{x[3]}</Status><button type="button" className="table-action" aria-label={`View ${x[0]} details`} onClick={()=>setSelectedEntity({name:x[0],detail:x[1],id:x[2],status:x[3],kind:page==="users"?"User account":"Provider record"})}><Icon name="chevron" size={16}/></button></div>)}</div></div>{selectedEntity&&<div className="modal-backdrop" role="presentation" onClick={()=>setSelectedEntity(null)}><section className="modal detail-modal" role="dialog" aria-modal="true" aria-labelledby="entity-detail-title" onClick={event=>event.stopPropagation()}><div className="modal-head"><div><div className="eyebrow">{selectedEntity.kind}</div><h2 id="entity-detail-title">{selectedEntity.name}</h2></div><button type="button" aria-label="Close record details" onClick={()=>setSelectedEntity(null)}><Icon name="close"/></button></div><div className="modal-detail-grid"><div><span>{page==="users"?"Email address":"Provider type"}</span><b>{selectedEntity.detail}</b></div><div><span>{page==="users"?"Account type":"Provider ID"}</span><b>{selectedEntity.id}</b></div><div><span>Status</span><b><Status>{selectedEntity.status}</Status></b></div></div><div className="form-actions"><Button onClick={()=>setSelectedEntity(null)}>Close details</Button></div></section></div>}</>;
  }
  if(page==="profile")return <ProfilePage role={role} profile={profiles[role]} onSave={nextProfile=>setProfiles({...profiles,[role]:nextProfile})} currentPassword={currentPassword} onPasswordChange={onPasswordChange}/>;
  return <><PageHead eyebrow="Audit trail" title={title} description={desc}/><div className="panel"><ActivityList/></div></>;
}

function ActivityList(){
  return <div className="activity-list">{[["Report DR-2025-041 verified","Elena D. Reyes · Administrator","Today, 9:42 AM","check"],["Alternative offer OF-224 sent","Balangay River Experiences","Yesterday, 4:18 PM","swap"],["Booking-link request BL-106 submitted","Mara L. Santos · Tourist","20 Apr, 11:06 AM","link"],["Provider record TP-007 activated","Elena D. Reyes · Administrator","19 Apr, 2:30 PM","building"]].map((a,i)=><div key={i}><span><Icon name={a[3]}/></span><p><b>{a[0]}</b><small>{a[1]}</small></p><time>{a[2]}</time></div>)}</div>;
}

function formatDate(date: string) {
  return new Date(`${date}T12:00:00`).toLocaleDateString("en-PH", { day:"numeric", month:"short", year:"numeric" });
}

export default function App() {
  const [entered,setEntered]=useState(false);
  const [role,setRole]=useState<Role>("tourist");
  const [page,setPage]=useState("dashboard");
  const [profiles,setProfiles]=useState<Record<Role,AccountProfile>>(()=>load("agian-profiles",initialProfiles));
  const [demoPasswords,setDemoPasswords]=useState<Record<Role,string>>({tourist:"demopassword",provider:"demopassword",admin:"demopassword"});
  const [reports,setReports]=useState<Report[]>(()=>load("agian-reports",initialReports));
  const [links,setLinks]=useState<LinkRequest[]>(()=>load("agian-links",[
    {id:"BL-106",reference:"TCI-883104",provider:"Timber City Inn",service:"Two-night Garden Room",submitted:"20 Apr 2025",status:"Pending Provider Review"},
    {id:"BL-101",reference:"LAT-22018",provider:"Lakbay Agusan Tours",service:"Balangay Shrine Guided Visit",submitted:"12 Apr 2025",status:"Approved"},
  ]));
  const [offers,setOffers]=useState<Offer[]>(()=>load("agian-offers",[
    {id:"OF-224",bookingId:"AB-48219",service:"Agusan Heritage River Tour",proposedDate:"24 Apr 2025",proposedTime:"10:00 AM",note:"Water levels are forecast to normalize. Please arrive at the riverside desk 20 minutes before departure.",status:"Offer Sent"},
  ]));
  const [notices,setNotices]=useState<Notice[]>(()=>load("agian-notices",[
    {id:1,title:"Alternative schedule received",detail:"Balangay River Experiences proposed 24 Apr at 10:00 AM for booking AB-48219.",time:"Yesterday, 4:18 PM",read:false,role:"tourist"},
    {id:2,title:"Disruption report verified",detail:"DR-2025-041 was verified. Review the administrator’s explanation.",time:"Yesterday, 10:24 AM",read:false,role:"tourist"},
    {id:3,title:"Booking-link request received",detail:"Mara Santos requested access to booking TCI-883104.",time:"20 Apr, 11:06 AM",read:false,role:"provider"},
    {id:4,title:"New report awaiting review",detail:"DR-2025-044 was added to the verification queue.",time:"3 hours ago",read:false,role:"admin"},
  ]));
  useEffect(()=>localStorage.setItem("agian-profiles",JSON.stringify(profiles)),[profiles]);
  useEffect(()=>localStorage.setItem("agian-reports",JSON.stringify(reports)),[reports]);
  useEffect(()=>localStorage.setItem("agian-links",JSON.stringify(links)),[links]);
  useEffect(()=>localStorage.setItem("agian-offers",JSON.stringify(offers)),[offers]);
  useEffect(()=>localStorage.setItem("agian-notices",JSON.stringify(notices)),[notices]);
  const unread=useMemo(()=>notices.filter(n=>!n.read&&(n.role===role||n.role==="all")).length,[notices,role]);
  const notify=(title:string,detail:string,target:Role)=>setNotices(n=>[{id:Date.now(),title,detail,time:"Just now",read:false,role:target},...n]);
  const displayName=role==="tourist"?(profiles.tourist.fullName||labels.tourist.name):role==="provider"?(profiles.provider.businessName||labels.provider.name):labels.admin.name;
  const account={name:displayName,detail:labels[role].detail,initials:initialsFromName(displayName),avatar:profiles[role]?.profilePicture || ""};
  if(!entered)return <Landing onEnter={r=>{setRole(r);setEntered(true);}}/>;
  let content:ReactNode;
  if(page==="dashboard")content=role==="tourist"?<TouristDashboard setPage={setPage} reports={reports} offers={offers} links={links} name={profiles.tourist.fullName||labels.tourist.name}/>:role==="provider"?<ProviderDashboard setPage={setPage} links={links} offers={offers} businessName={profiles.provider.businessName||labels.provider.name}/>:<AdminDashboard setPage={setPage} reports={reports} offers={offers}/>;
  else if(page==="report"||page==="reports")content=<ReportsPage key={page} role={role} reports={reports} setReports={setReports} notify={notify} startForm={page==="report"}/>;
  else if(page==="verification")content=<VerificationPage reports={reports} setReports={setReports} notify={notify}/>;
  else if(page==="links")content=<LinksPage role={role} links={links} setLinks={setLinks} notify={notify}/>;
  else if(page==="offers"||page==="rescheduling")content=<OffersPage role={role} offers={offers} setOffers={setOffers} notify={notify}/>;
  else if(page==="notifications")content=<NotificationsPage notices={notices} role={role} setNotices={setNotices}/>;
  else content=<GenericPage page={page} role={role} profiles={profiles} setProfiles={setProfiles} currentPassword={demoPasswords[role]} onPasswordChange={password=>setDemoPasswords(current=>({...current,[role]:password}))}/>;
  return <AppShell role={role} setRole={setRole} exit={()=>setEntered(false)} page={page} setPage={setPage} unread={unread} account={account}>{content}</AppShell>;
}

function load<T>(key:string,fallback:T):T{try{const saved=localStorage.getItem(key);return saved?JSON.parse(saved):fallback;}catch{return fallback;}}
